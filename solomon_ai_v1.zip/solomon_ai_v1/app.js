const $ = (id) => document.getElementById(id);
const messages = $("messages");
const promptBox = $("prompt");
let lastAnswer = "";
let listening = false;
const memoryKey = "solomon-ai-notes-v1";

function addMessage(role, text) {
  const article = document.createElement("article");
  article.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "assistant" ? "S" : "You";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const label = document.createElement("strong");
  label.textContent = role === "assistant" ? "Solomon AI" : "You";
  const body = document.createElement("p");
  body.textContent = text;
  bubble.append(label, body);
  article.append(avatar, bubble);
  messages.append(article);
  messages.scrollTop = messages.scrollHeight;
}
function speak(text) {
  if (!("speechSynthesis" in window)) {
    addMessage("assistant", "Text-to-speech is not available in this browser.");
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-GH";
  window.speechSynthesis.speak(utterance);
}
function getNotes() {
  try { return JSON.parse(localStorage.getItem(memoryKey) || "[]"); }
  catch { return []; }
}
function saveNote(note) {
  const notes = getNotes();
  notes.push({note, createdAt: new Date().toISOString()});
  localStorage.setItem(memoryKey, JSON.stringify(notes.slice(-100)));
}
function offlineReply(raw) {
  const q = raw.trim();
  const lower = q.toLowerCase();
  if (!q) return "Please type or say a command.";
  if (/\b(hi|hello|hey)\b/.test(lower)) return "Hello! What would you like me to do?";
  if (lower.includes("time")) return `The time on this device is ${new Date().toLocaleTimeString()}.`;
  if (lower.includes("date") || lower.includes("today")) return `Today is ${new Date().toLocaleDateString()}.`;
  if (lower.includes("what can you do") || lower.includes("offline")) return "Offline I can tell the time and date, save simple notes on this device, show saved notes, speak text, and clear this chat. General AI answers need an online AI service.";
  if (lower.startsWith("remember that ") || lower.startsWith("save a note ")) {
    const note = q.replace(/^remember that\s+|^save a note\s+/i, "").trim();
    if (!note) return "Tell me what you want me to remember.";
    saveNote(note);
    return "Saved on this device. You can say “show my notes” later. Notes do not automatically sync to your other devices.";
  }
  if (lower.includes("show my notes") || lower.includes("what do you remember")) {
    const notes = getNotes();
    return notes.length ? "Your saved notes:\n" + notes.map((n,i) => `${i+1}. ${n.note}`).join("\n") : "You have no saved notes on this device yet.";
  }
  if (lower.includes("read your last answer aloud") || lower === "speak") {
    if (!lastAnswer) return "I don't have an answer to read yet.";
    speak(lastAnswer); return "Reading my previous answer aloud.";
  }
  if (lower.includes("stop speaking")) {
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    return "Speech stopped.";
  }
  if (lower.includes("clear the chat") || lower === "clear chat") {
    messages.replaceChildren();
    return "Chat cleared. Your saved notes are still on this device.";
  }
  if (lower.includes("help")) return "Try: “What time is it?”, “Remember that my project is FixForce”, “Show my notes”, or “Read your last answer aloud”.";
  return "I’m currently in offline mode, so I can only handle built-in commands. Connect an online AI service in a later version for open-ended questions.";
}
async function handleSend(text = promptBox.value) {
  const value = text.trim();
  if (!value) return;
  addMessage("user", value);
  promptBox.value = "";
  const reply = offlineReply(value);
  lastAnswer = reply;
  addMessage("assistant", reply);
}
$("send").addEventListener("click", () => handleSend());
promptBox.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
});
document.querySelectorAll("[data-command]").forEach(btn => btn.addEventListener("click", () => handleSend(btn.dataset.command)));

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognition = new SpeechRecognition();
  recognition.lang = "en-GH";
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.onresult = event => { promptBox.value = event.results[0][0].transcript; handleSend(); };
  recognition.onerror = () => { $("voice-status").textContent = "Voice input stopped. You can still type your command."; listening = false; $("mic").textContent = "🎙"; };
  recognition.onend = () => { listening = false; $("mic").textContent = "🎙"; };
  $("mic").addEventListener("click", () => {
    if (listening) { recognition.stop(); return; }
    try { recognition.start(); listening = true; $("mic").textContent = "⏹"; $("voice-status").textContent = "Listening…"; }
    catch { $("voice-status").textContent = "Could not start the microphone. Check browser permission."; }
  });
} else {
  $("mic").disabled = true;
  $("mic").title = "Voice input is not supported in this browser";
  $("voice-status").textContent = "This browser does not support speech recognition. Try a supported browser or type your commands.";
}
function updateConnection() {
  const online = navigator.onLine;
  $("connection").textContent = online ? "● Online" : "● Offline";
  $("connection").style.color = online ? "var(--green)" : "#f0bd65";
}
window.addEventListener("online", updateConnection);
window.addEventListener("offline", updateConnection);
updateConnection();
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
