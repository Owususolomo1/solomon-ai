# Solomon AI v1.0

An installable, offline-first web app starter for Android, iPhone, tablets and desktop browsers.

## Included in version 1
- Text chat interface
- Speech input where the browser supports the Web Speech API
- Spoken responses using the device's speech synthesis
- Offline built-in commands: time, date, help, notes, speak last answer, clear chat
- Notes saved locally in the current browser
- PWA manifest and service worker for caching the app shell

## Run it locally
A service worker requires HTTPS or localhost. From this folder run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` in your browser.

## Put it online
Upload the files to a static web host that supports HTTPS (for example, GitHub Pages or another static hosting provider). Open the HTTPS address on your phone and use the browser's **Add to Home Screen** / **Install app** option.

## Important limitations
- “All devices” means modern browsers that support standard web features. Voice recognition support differs by browser and operating system; microphone access usually requires HTTPS and permission.
- Offline speech recognition is not guaranteed. The browser may use an online speech service. Typed built-in commands work offline after the app has been cached.
- Device speech voices vary; offline speech output depends on voices installed on the device.
- Notes are stored in that browser on that device. This first version does not sync notes between devices.
- This version does not yet contain an online large-language-model connection. Add a secure backend in the next stage; never put a private AI API key in browser JavaScript.

## Next development stage
1. Add a small HTTPS backend for online AI requests.
2. Keep API credentials on the backend, not in the web app.
3. Add opt-in cloud sync for notes and preferences.
4. Add permission-based device actions. The app must ask before sending messages, deleting files, spending money, or taking other consequential actions.
